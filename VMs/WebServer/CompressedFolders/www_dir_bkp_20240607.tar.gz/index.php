<?php

$servername = "192.168.1.36";
$port = "3306";
$username = "lcars";
$password = "NCC1701D";
$dbname = "ingenieria";



$conn = new MySQLi ($servername, $username, $password, $dbname);

// Error de conexión
if ($conn->connect_error) {
  die("Error de conexion: " . $conn->connect_error);
}

$sql = "select alumnos.legajo 'legajo', 
               alumnos.apellido 'apellido', 
               alumnos.nombres 'nombre',
                modulos.nom_modulo 'materia', 
               notas.nota 'nota'
        from   alumnos, 
               modulos, 
               notas 
        where  alumnos.legajo=notas.legajo 
           and modulos.cod_modulo = notas.cod_modulo;";

if ($result = $conn->query($sql)) {

while($row = $result->fetch_assoc()) {
    echo "legajo: " . $row["legajo"]. " -Nombre:  " . $row["nombre"]." " . $row["apellido"]. " | " . $row["materia"]. " ---> " ."Nota: " . $row["nota"]."<br>";
  }
}

$conn->close();
?>

