#!/bin/bash

show_help() {
    # No parameters required
    echo "Usage: $0 [source_directory] [destination_directory]"
    echo "Example: $0 /etc /backup_dir"
    exit 0
}

check_mounted() {
    # 1 parameter which is directory to check if mounted.
    local DIR=$1

    # List of directories to check
    local CHECK_DIRS=("/backup_dir" "/www_dir" "/db_dir")

    # Check if $DIR is in the list of directories to check
    if [[ " ${CHECK_DIRS[@]} " =~ " $DIR " ]]; then
        # Check if $DIR is mounted
        if mountpoint -q -- "$DIR"; then
            echo "$DIR is mounted."
        else
            echo "$DIR is not mounted."
            exit 1
        fi
    else
        echo "$DIR is not one of /backup_dir, /www_dir, or /db_dir. So not necessary to check if mounted."
    fi
}

# Validate if the amount of args is != 2 or 1st arg = -h or 1st arg = --help then show help
if [[ "$#" -ne 2 || "$1" == "-h" || "$1" == "--help" ]]; then
    show_help
fi

# Source and destination directories are first and second arguments respectively
SOURCE_DIR=$1
DEST_DIR=$2

# Validate source and destination directories
if [ ! -d "$SOURCE_DIR" ]; then
    echo "Source directory $SOURCE_DIR does not exist or is not a directory."
    exit 1
fi

if [ ! -d "$DEST_DIR" ]; then
    echo "Destination directory $DEST_DIR does not exist or is not a directory."
    exit 1
fi

check_mounted "$SOURCE_DIR"
check_mounted "$DEST_DIR"

# Create backup file name
TIMESTAMP=$(date +%Y%m%d)
DIR_NAME=$(basename "$SOURCE_DIR")
BACKUP_FILE="${DEST_DIR}/${DIR_NAME}_bkp_${TIMESTAMP}.tar.gz"

# Create the backup
tar -czf "$BACKUP_FILE" -C "$SOURCE_DIR" .

# Check the output of previous command to see if successful
if [ $? -eq 0 ]; then
    echo "Backup of $SOURCE_DIR completed successfully and saved to $BACKUP_FILE"
else
    echo "Backup of $SOURCE_DIR failed."
    exit 1
fi

#echo "Hi Adolfo!"
